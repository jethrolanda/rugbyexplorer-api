## DOCUMENTATION

Use the following shortcodes:

---

## Plugin Blocks

This plugin uses Fuel Logic Service Area block.

## Zip File

To create a .zip file of this plugin. First clone this repository and create a zip using this code:
`git archive -o fusesport-api.zip HEAD`
