Run this command to compile style.scss to a minified css file called style.min.css

```
sass --watch style.scss:style.min.css --style compressed
```
