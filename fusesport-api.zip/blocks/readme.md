Generate interactivity block:
`npx @wordpress/create-block@latest my-first-interactive-block --template @wordpress/create-block-interactive-template`

Source:
https://developer.wordpress.org/block-editor/reference-guides/interactivity-api/iapi-quick-start-guide/
